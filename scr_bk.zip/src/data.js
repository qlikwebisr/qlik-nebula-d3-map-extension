export default {
  targets: [
    {
      path: "/qHyperCubeDef",
      dimensions: {
        min: 1,
        max: 2,
      },
      measures: {
        min: 1,
        max: 2,
      },
    },
  ],
}
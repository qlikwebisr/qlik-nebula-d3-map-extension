define(['./dist/neb-test'], (supernova) => supernova);
